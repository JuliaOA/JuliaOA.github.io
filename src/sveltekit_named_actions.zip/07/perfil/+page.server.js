import { fail, redirect } from '@sveltejs/kit';

export const actions = {
  atualizarPerfil: async ({ request }) => {
    const data = await request.formData();
    const nome = data.get('nome');
    const email = data.get('email');
    const senhaAtual = data.get('senhaAtual');

    if (!nome || !email || senhaAtual !== 'senhasecreta') {
      return fail(400, {
        error: 'Todos os campos são obrigatórios e a senha deve ser correta.',
        nome,
        email
      });
    }

    throw redirect(303, '/07/perfil?status=perfil_atualizado');
  },

  alterarSenha: async ({ request }) => {
    const data = await request.formData();
    const senhaAtual = data.get('senhaAtual');
    const novaSenha = data.get('novaSenha');
    const confirmarNovaSenha = data.get('confirmarNovaSenha');

    if (!senhaAtual || !novaSenha || !confirmarNovaSenha) {
      return fail(400, { error: 'Todos os campos são obrigatórios.' });
    }
    if (senhaAtual !== 'senhasecreta') {
      return fail(400, { error: 'Senha atual incorreta.' });
    }
    if (novaSenha !== confirmarNovaSenha) {
      return fail(400, { error: 'As novas senhas não coincidem.' });
    }
    if (novaSenha.length < 4) {
      return fail(400, { error: 'A nova senha deve ter pelo menos 4 caracteres.' });
    }

    throw redirect(303, '/07/perfil?status=senha_alterada');
  },

  desativarConta: async ({ request }) => {
    const data = await request.formData();
    const confirmarDesativacao = data.get('confirmarDesativacao');
    const senhaAtual = data.get('senhaAtual');

    if (confirmarDesativacao !== 'on' || senhaAtual !== 'senhasecreta') {
      return fail(400, { error: 'Você deve confirmar a desativação e fornecer a senha atual.' });
    }

    throw redirect(303, '/07/login?status=conta_desativada');
  }
};