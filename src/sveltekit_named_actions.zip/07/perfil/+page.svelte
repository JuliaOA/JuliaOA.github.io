<script>
  export let form;
</script>

<form method="POST" action="?/atualizarPerfil">
  <label>
    Nome:
    <input name="nome" type="text" value={form?.nome ?? ''} required />
  </label>
  <br />
  <label>
    E-mail:
    <input name="email" type="email" value={form?.email ?? ''} required />
  </label>
  <br />
  <label>
    Senha Atual:
    <input name="senhaAtual" type="password" required />
  </label>
  <br />
  <label>
    Nova Senha:
    <input name="novaSenha" type="password" />
  </label>
  <br />
  <label>
    Confirmar Nova Senha:
    <input name="confirmarNovaSenha" type="password" />
  </label>
  <br />
  <label>
    <input name="confirmarDesativacao" type="checkbox" /> Confirmo que desejo desativar minha conta
  </label>
  <br />
  <button type="submit">Salvar Alterações</button>
  <button type="submit" formaction="?/alterarSenha">Alterar Senha</button>
  <button type="submit" formaction="?/desativarConta">Desativar Minha Conta</button>
</form>

{#if form?.error}
  <p style="color: red">{form.error}</p>
{/if}