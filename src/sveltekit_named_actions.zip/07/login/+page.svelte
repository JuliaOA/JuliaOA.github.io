<script>
  import { page } from '$app/stores';
  $: status = $page.url.searchParams.get('status');
</script>

{#if status === 'conta_desativada'}
  <p style="color: green">Conta desativada com sucesso!</p>
{/if}
<h1>Login</h1>
<!-- Coloque seu formulário de login aqui -->